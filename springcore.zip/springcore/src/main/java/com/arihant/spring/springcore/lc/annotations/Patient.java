package com.arihant.spring.springcore.lc.annotations;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class Patient  {

    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        System.out.println("\u001B[32m" + "\nInside setter method." + "\u001B[0m");
        this.id = id;
    }

    @Override
    public String toString() {
        return "Patient { " +
                "id=" + id +
                " }";
    }

    @PostConstruct
    public void hi() {
        System.out.println("\nThis is an init method.");
    }

    @PreDestroy
    public void bye() {
        System.out.println("\u001B[31m" + "\nThis is a destroy method." + "\u001B[0m");
    }

}
package com.arihant.spring.springcore.reftypes;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

    public static final String BLUE = "\u001B[34m";
    public static final String RESET = "\u001B[0m";

	public static void main(String[] args) {

        ApplicationContext context = new ClassPathXmlApplicationContext("scoresconfig.xml");
        Students stud = (Students) context.getBean("student");

        System.out.println(BLUE + "This is an example of STUDENTS in spring" + RESET);
        System.out.println(stud);



	}
}

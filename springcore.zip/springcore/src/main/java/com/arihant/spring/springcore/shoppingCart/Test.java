package com.arihant.spring.springcore.shoppingCart;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

    public static final String BLUE = "\u001B[34m";
    public static final String RESET = "\u001B[0m";

	public static void main(String[] args) {

        ApplicationContext context = new ClassPathXmlApplicationContext("shoppingcartconfig.xml");
        Cart cart = (Cart) context.getBean("cart");

        System.out.println(BLUE + "\n\nThis is an example of SHOPPING CART in spring" + RESET);
        System.out.println(cart);
	}
}

package com.arihant.spring.springcore.map;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

    public static final String BLUE = "\u001B[34m";
    public static final String RESET = "\u001B[0m";

	public static void main(String[] args) {

    ApplicationContext context = new ClassPathXmlApplicationContext("mapconfig.xml");

    Customer cust = (Customer) context.getBean("customer");

        System.out.println(BLUE + "This is an example of MAP in spring" + RESET);
        System.out.println(cust);

	}

}

package com.arihant.spring.springcore.lc.annotations;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

    public static final String BLUE = "\u001B[34m";
    public static final String RESET = "\u001B[0m";

	public static void main(String[] args) {

        AbstractApplicationContext context = new ClassPathXmlApplicationContext("com/arihant/spring/springcore/lc/annotations/config.xml");
        Patient pat = (Patient) context.getBean("patient");

        System.out.println(BLUE + "\nThis is an example of PATIENT ANNOTATIONS in spring" + RESET);
        System.out.println(pat);

        context.registerShutdownHook();

	}
}

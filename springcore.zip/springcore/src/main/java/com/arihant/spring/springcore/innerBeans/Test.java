package com.arihant.spring.springcore.innerBeans;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

    public static final String BLUE = "\u001B[34m";
    public static final String RESET = "\u001B[0m";

	public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("com/arihant/spring/springcore/innerBeans/config.xml");
        Employee employee = (Employee) context.getBean("employee");

        System.out.println(BLUE + "\nThis is an example of EMPLOYEE-ADDRESS NESTED CONFIG in spring" + RESET);
        System.out.println(employee);


    }
}

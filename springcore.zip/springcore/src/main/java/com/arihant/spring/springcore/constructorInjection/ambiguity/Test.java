package com.arihant.spring.springcore.constructorInjection.ambiguity;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

    public static final String BLUE = "\u001B[34m";
    public static final String RESET = "\u001B[0m";

	public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("com/arihant/spring/springcore/constructorInjection/ambiguity/config.xml");
        Addition addition = (Addition) context.getBean("addition");

        System.out.println(BLUE + "\nThis is an example of ADDITION CONSTRUCTOR INJECTION AMBIGUITY in spring" + RESET);
        System.out.println(addition);

    }
}

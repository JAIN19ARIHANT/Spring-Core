package com.arihant.spring.springcore.dependencyCheckAssignment;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.util.SocketUtils;

public class Test {

    public static final String BLUE = "\u001B[34m";
    public static final String RESET = "\u001B[0m";

	public static void main(String[] args) {

        ApplicationContext context = new ClassPathXmlApplicationContext
                ("com/arihant/spring/springcore/dependencyCheckAssignment/config.xml");

        University uni = (University) context.getBean("university");

        System.out.println(BLUE + "This is an example of UNIVERSITY DEPENDENCY CHECK");
        System.out.println(uni);
	}
}

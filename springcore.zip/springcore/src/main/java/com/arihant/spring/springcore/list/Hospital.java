package com.arihant.spring.springcore.list;

import java.util.List;

public class Hospital {

	private String name;
	private List<String> departments;

	// Note: Explicitly adding a default constructor here is a great habit!
	public Hospital() {
		super();
	}

	public List<String> getDepartments() {
		return departments;
	}

	public void setDepartments(List<String> departments) {
		this.departments = departments;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
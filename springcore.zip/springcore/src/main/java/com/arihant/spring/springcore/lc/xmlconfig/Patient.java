package com.arihant.spring.springcore.lc.xmlconfig;

// Life Cycle -> XML Config

public class Patient {

    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        System.out.println("\u001B[32m" + "\nInside setter method." + "\u001B[0m");
        this.id = id;
    }

    @Override
    public String toString() {
        return "Patient { " +
                "id=" + id +
                " }";
    }

    public void hi() {
        System.out.println("\nThis is an init method.");
    }

    public void bye() {
        System.out.println("\u001B[31m" + "\nThis is a destroy method." + "\u001B[0m");
    }

}
package com.arihant.spring.springcore.constructorInjection.ambiguity;

public class Addition {

//    The ambiguit here is that if we swith the positons of the constructors INT <---> DOUBLE,
//    Then the o/p will be Inside Constructor DOUBLE.

    Addition(int a, int b) {
        System.out.println("Inside Constructor INT");
    }

    Addition(double a, double b) {
        System.out.println("Inside Constructor DOUBLE");
    }

//    When you pass values using <constructor-arg value="10" /> in your XML,
//    Spring reads "10" and "20" as literal Strings.

    Addition(String a, String b) {
        System.out.println("Inside Constructor STRING");
    }

}

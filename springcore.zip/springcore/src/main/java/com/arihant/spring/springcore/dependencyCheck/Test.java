package com.arihant.spring.springcore.dependencyCheck;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

    public static final String BLUE = "\u001B[34m";
    public static final String RESET = "\u001B[0m";

	public static void main(String[] args) {

        ApplicationContext context = new ClassPathXmlApplicationContext("com/arihant/spring/springcore/dependencyCheck/config.xml");
        Prescription Prescription = (Prescription) context.getBean("prescription");

        System.out.println(BLUE + "\nThis is an example of Prescription DEPENDENCY CHECK in spring" + RESET);
        System.out.println(Prescription);



	}
}

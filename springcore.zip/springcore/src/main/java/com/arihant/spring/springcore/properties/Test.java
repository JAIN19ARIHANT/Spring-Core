package com.arihant.spring.springcore.properties;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

    public static final String BLUE = "\u001B[34m";
    public static final String RESET = "\u001B[0m";

	public static void main(String[] args) {

    ApplicationContext context = new ClassPathXmlApplicationContext("propconfig.xml");

        CountriesAndLanguages cl = (CountriesAndLanguages) context.getBean("countriesAndLanguages");

        System.out.println(BLUE + "This is an example of PROPERTIES in spring" + RESET);
        System.out.println(cl);

	}
}
